import { ExceptionFilter, Catch, ArgumentsHost, HttpException, HttpStatus } from '@nestjs/common';
import type { Response as ExpressResponse } from 'express';
import type { FastifyReply } from 'fastify';

import { ValidationableException } from '../../exceptions/interfaces/validationable-exception.interface';
import { BaseException } from '../../exceptions/base.exception';
import { HttpResponseDescriptions } from '../enums/http-response-descriptions.enum';


/**
 * Common exception filter for handling exceptions based
 * on the `BaseException` class
 */
@Catch(BaseException)
export class CommonExceptionFilter implements ExceptionFilter {
    catch(exception: BaseException & ValidationableException, host: ArgumentsHost) {
        if (typeof exception.asValidationException !== 'undefined')
            exception = exception.asValidationException();

        const ctx = host.switchToHttp();
        const response: FastifyReply | ExpressResponse = ctx.getResponse();
        const statusCode = (exception.constructor as typeof BaseException).HTTPStatusCode || 500;
        const errorResponseBody = {
            statusCode,
            description: HttpResponseDescriptions[
                HttpStatus[statusCode].toString() as keyof typeof HttpResponseDescriptions
            ],
            ...exception // Exceptions can be converted in plain objects
        } as unknown as HttpException

        response.status(statusCode)
        response.send(errorResponseBody);
    }
}
